cd $PINNS
scp -r EquationModels mroberto@euler.ethz.ch:/cluster/scratch/mroberto/Source/
scp *.py mroberto@euler.ethz.ch:/cluster/scratch/mroberto/Source/

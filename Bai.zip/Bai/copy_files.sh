cd $PINNS
scp -r EquationModels mroberto@login.leonhard.ethz.ch:/cluster/scratch/mroberto/Source/
scp *.py mroberto@login.leonhard.ethz.ch:/cluster/scratch/mroberto/Source/
